"""
Problème(s) connu(s) : #1 Le comportement de la balle au début du jeu est défini dans le main et 
                          peut difficilement être évolutif, 
                          par exemple dans le cas où il y aurait une version avec plusieurs balles
Raison(s) (si connue):
Solution(s) envisagée(s) (s'il y en a):
Problème(s) résolu(s) :
"""
import pyxel
from Plateforme import Plateforme
from Balle import Balle

class Jeu:
    def __init__(self):

        # taille de la fenetre 128x128 pixels
        # ne pas modifier
        pyxel.init(128, 128, title="Nuit du c0de")

        # création de la pateforme
        self.plateforme_1 = Plateforme (20,5)

        # création de la balle
        self.balle = Balle(2)

        self.x_balle = 0

        self.game_started = False # indicateur de l'état du Jeu (False -> jeu non commencé
                                  #                              True -> jeu commencé)

        pyxel.run(self.update,self.draw)

    def start(self): # déclencheur du jeu
        if pyxel.btn(pyxel.KEY_RIGHT) :
            self.game_started = True
            self.x_balle = 1
        if pyxel.btn(pyxel.KEY_LEFT) :
            self.game_started = True
            self.x_balle = -1
#======================================================================================================== UPDATE

    def update(self):
        """mise à jour des variables (30 fois par seconde)"""
        if self.game_started: # Tant que le Jeu n'est pas commencé, on attend
            
            # deplacement de la plateforme
            self.plateforme_1.deplacement()

            # deplacement de la balle
            self.balle.deplacement(self.x_balle,-1)
        else :
            self.start()
#======================================================================================================== DRAW

    def draw(self):
        """création et positionnement des objets (30 fois par seconde)"""

        # vide la fenetre
        pyxel.cls(0)

        # vaisseau (carre 20x5)
        pyxel.rect(self.plateforme_1.x, self.plateforme_1.y, 20, 5, 1)

        # balle (cercle de rayon 2)
        pyxel.circ(self.balle.x, self.balle.y, self.balle.ray, 3)

Jeu()