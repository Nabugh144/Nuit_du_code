import pyxel

class Balle ():
    
    def __init__ (self, rayon):
        
        # position de la balle
        self.ray = rayon
        self.x = 64
        self.y = 122 - rayon
    
    def deplacement (self, x, y):
        self.y += y
        self.x += x

        
